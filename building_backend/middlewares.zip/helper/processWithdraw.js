// helper/processWithdraw.js
const User  = require('../models'); // Assuming you have a User model to query the database

async function processWithdraw(ctx) {
 
}

module.exports = { processWithdraw };
